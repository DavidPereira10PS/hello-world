package laboratorio;


public class Canario implements PuedeCantar {
    
    
    public void cantar() {
        System.out.println("pio pio pio");
    }
}
