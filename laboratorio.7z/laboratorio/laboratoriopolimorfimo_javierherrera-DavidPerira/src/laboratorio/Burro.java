
package laboratorio;


public class Burro implements PuedeCantar {
    
    
    
    
    public void cantar() {
        System.out.println("Rebuznar");
    }

}
