
package laboratorio;

public interface PuedeCantar {
    
    public void cantar();
}
